<footer class="footer">
    <div class="container-fluid">
        <div class="row text-muted">
            <div class="col-12 text-center">
                <h4>Developed By MeriTech Solution</h4>
            </div>
        </div>
    </div>
</footer>
