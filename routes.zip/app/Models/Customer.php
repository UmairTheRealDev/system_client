<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'store_name',
        'owner_name',
        'location',
        'province',
        'region',
        'city',
        'area',
        'contact_no',
        'day',
    ];
}
